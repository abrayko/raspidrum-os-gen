var structgig_1_1buffer__t =
[
    [ "NullExtensionSize", "structgig_1_1buffer__t.html#a328af68c49213282e23a4b828653aaf3", null ],
    [ "pStart", "structgig_1_1buffer__t.html#ad97c71cb5ed59c034ff1a54650d74ec5", null ],
    [ "Size", "structgig_1_1buffer__t.html#afc030037f7c271b7b76345e70ad43ba5", null ]
];