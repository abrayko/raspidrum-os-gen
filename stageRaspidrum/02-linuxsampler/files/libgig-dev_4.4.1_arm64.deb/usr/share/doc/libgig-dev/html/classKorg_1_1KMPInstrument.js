var classKorg_1_1KMPInstrument =
[
    [ "Name", "classKorg_1_1KMPInstrument.html#a4bd211e192f344a9a030fd1024ba4b1a", null ],
    [ "Attributes", "classKorg_1_1KMPInstrument.html#a2ca28700a4ee0b8b1a3c36477d47f624", null ],
    [ "Name16", "classKorg_1_1KMPInstrument.html#a0fbaae8244bedaa8c11f5be517460fc7", null ],
    [ "Name24", "classKorg_1_1KMPInstrument.html#a484c2102d6fd0385c9f1c1cfdb796f47", null ]
];