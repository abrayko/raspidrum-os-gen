var annotated_dup =
[
    [ "DLS", "namespaceDLS.html", [
      [ "Articulation", "classDLS_1_1Articulation.html", "classDLS_1_1Articulation" ],
      [ "Articulator", "classDLS_1_1Articulator.html", "classDLS_1_1Articulator" ],
      [ "Connection", "classDLS_1_1Connection.html", null ],
      [ "dlsid_t", "structDLS_1_1dlsid__t.html", null ],
      [ "Exception", "classDLS_1_1Exception.html", null ],
      [ "File", "classDLS_1_1File.html", "classDLS_1_1File" ],
      [ "Info", "classDLS_1_1Info.html", "classDLS_1_1Info" ],
      [ "Instrument", "classDLS_1_1Instrument.html", "classDLS_1_1Instrument" ],
      [ "range_t", "structDLS_1_1range__t.html", "structDLS_1_1range__t" ],
      [ "Region", "classDLS_1_1Region.html", "classDLS_1_1Region" ],
      [ "Resource", "classDLS_1_1Resource.html", "classDLS_1_1Resource" ],
      [ "Sample", "classDLS_1_1Sample.html", "classDLS_1_1Sample" ],
      [ "sample_loop_t", "structDLS_1_1sample__loop__t.html", "structDLS_1_1sample__loop__t" ],
      [ "Sampler", "classDLS_1_1Sampler.html", "classDLS_1_1Sampler" ],
      [ "Storage", "classDLS_1_1Storage.html", "classDLS_1_1Storage" ],
      [ "version_t", "structDLS_1_1version__t.html", null ]
    ] ],
    [ "gig", "namespacegig.html", [
      [ "buffer_t", "structgig_1_1buffer__t.html", "structgig_1_1buffer__t" ],
      [ "crossfade_t", "structgig_1_1crossfade__t.html", "structgig_1_1crossfade__t" ],
      [ "dimension_def_t", "structgig_1_1dimension__def__t.html", "structgig_1_1dimension__def__t" ],
      [ "DimensionRegion", "classgig_1_1DimensionRegion.html", "classgig_1_1DimensionRegion" ],
      [ "eg_opt_t", "structgig_1_1eg__opt__t.html", "structgig_1_1eg__opt__t" ],
      [ "Exception", "classgig_1_1Exception.html", null ],
      [ "File", "classgig_1_1File.html", "classgig_1_1File" ],
      [ "Group", "classgig_1_1Group.html", "classgig_1_1Group" ],
      [ "Instrument", "classgig_1_1Instrument.html", "classgig_1_1Instrument" ],
      [ "leverage_ctrl_t", "structgig_1_1leverage__ctrl__t.html", "structgig_1_1leverage__ctrl__t" ],
      [ "MidiRule", "classgig_1_1MidiRule.html", null ],
      [ "MidiRuleAlternator", "classgig_1_1MidiRuleAlternator.html", "classgig_1_1MidiRuleAlternator" ],
      [ "MidiRuleCtrlTrigger", "classgig_1_1MidiRuleCtrlTrigger.html", "classgig_1_1MidiRuleCtrlTrigger" ],
      [ "MidiRuleLegato", "classgig_1_1MidiRuleLegato.html", "classgig_1_1MidiRuleLegato" ],
      [ "MidiRuleUnknown", "classgig_1_1MidiRuleUnknown.html", null ],
      [ "playback_state_t", "structgig_1_1playback__state__t.html", "structgig_1_1playback__state__t" ],
      [ "range_t", "structgig_1_1range__t.html", "structgig_1_1range__t" ],
      [ "Region", "classgig_1_1Region.html", "classgig_1_1Region" ],
      [ "Sample", "classgig_1_1Sample.html", "classgig_1_1Sample" ],
      [ "Script", "classgig_1_1Script.html", "classgig_1_1Script" ],
      [ "ScriptGroup", "classgig_1_1ScriptGroup.html", "classgig_1_1ScriptGroup" ]
    ] ],
    [ "Korg", "namespaceKorg.html", [
      [ "Exception", "classKorg_1_1Exception.html", null ],
      [ "KMPInstrument", "classKorg_1_1KMPInstrument.html", "classKorg_1_1KMPInstrument" ],
      [ "KMPRegion", "classKorg_1_1KMPRegion.html", "classKorg_1_1KMPRegion" ],
      [ "KSFSample", "classKorg_1_1KSFSample.html", "classKorg_1_1KSFSample" ]
    ] ],
    [ "RIFF", "namespaceRIFF.html", [
      [ "Chunk", "classRIFF_1_1Chunk.html", "classRIFF_1_1Chunk" ],
      [ "Exception", "classRIFF_1_1Exception.html", null ],
      [ "File", "classRIFF_1_1File.html", "classRIFF_1_1File" ],
      [ "List", "classRIFF_1_1List.html", "classRIFF_1_1List" ],
      [ "progress_t", "structRIFF_1_1progress__t.html", "structRIFF_1_1progress__t" ]
    ] ],
    [ "Serialization", "namespaceSerialization.html", [
      [ "Archive", "classSerialization_1_1Archive.html", "classSerialization_1_1Archive" ],
      [ "DataType", "classSerialization_1_1DataType.html", "classSerialization_1_1DataType" ],
      [ "Exception", "classSerialization_1_1Exception.html", "classSerialization_1_1Exception" ],
      [ "Member", "classSerialization_1_1Member.html", "classSerialization_1_1Member" ],
      [ "Object", "classSerialization_1_1Object.html", "classSerialization_1_1Object" ],
      [ "UID", "classSerialization_1_1UID.html", "classSerialization_1_1UID" ]
    ] ],
    [ "sf2", "namespacesf2.html", [
      [ "Region", "classsf2_1_1Region.html", "classsf2_1_1Region" ]
    ] ],
    [ "AkaiDisk", "classAkaiDisk.html", null ],
    [ "AkaiPartition", "classAkaiPartition.html", null ],
    [ "AkaiProgram", "classAkaiProgram.html", null ],
    [ "AkaiVolume", "classAkaiVolume.html", null ],
    [ "DiskImage", "classDiskImage.html", "classDiskImage" ]
];