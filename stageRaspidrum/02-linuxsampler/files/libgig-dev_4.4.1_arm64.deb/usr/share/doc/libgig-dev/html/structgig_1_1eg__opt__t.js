var structgig_1_1eg__opt__t =
[
    [ "AttackCancel", "structgig_1_1eg__opt__t.html#abe94cf0fe5cfb69f2ed0b6b4efd0082f", null ],
    [ "AttackHoldCancel", "structgig_1_1eg__opt__t.html#a013f5a620d265aa66470162808a6fe71", null ],
    [ "Decay1Cancel", "structgig_1_1eg__opt__t.html#a246a094f6d8f95ad8d408268bc650231", null ],
    [ "Decay2Cancel", "structgig_1_1eg__opt__t.html#ae36427d642e060417e33e903ef16e963", null ],
    [ "ReleaseCancel", "structgig_1_1eg__opt__t.html#a41c279e5e2aa4483f031bb934e4ff4ed", null ]
];