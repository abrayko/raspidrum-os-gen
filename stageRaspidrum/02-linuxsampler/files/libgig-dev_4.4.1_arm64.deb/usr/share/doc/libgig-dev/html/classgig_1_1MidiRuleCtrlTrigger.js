var classgig_1_1MidiRuleCtrlTrigger =
[
    [ "ControllerNumber", "classgig_1_1MidiRuleCtrlTrigger.html#a0b8ead95913aba534eaf26591b6eb48e", null ],
    [ "Triggers", "classgig_1_1MidiRuleCtrlTrigger.html#addeb82e66e6ddf0cd54361a2a0a16531", null ]
];