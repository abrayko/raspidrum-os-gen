var namespaceKorg =
[
    [ "Exception", "classKorg_1_1Exception.html", null ],
    [ "KMPInstrument", "classKorg_1_1KMPInstrument.html", "classKorg_1_1KMPInstrument" ],
    [ "KMPRegion", "classKorg_1_1KMPRegion.html", "classKorg_1_1KMPRegion" ],
    [ "KSFSample", "classKorg_1_1KSFSample.html", "classKorg_1_1KSFSample" ],
    [ "libraryName", "namespaceKorg.html#a5953e638e4e7cfc041c8606a5af07afc", null ],
    [ "libraryVersion", "namespaceKorg.html#a2f205140eddd7e48169848e0c9c2d868", null ],
    [ "readText12", "namespaceKorg.html#af917986075cdccaeaae0b2cdbbc539c8", null ],
    [ "readText16", "namespaceKorg.html#a5a341bd93e19f700a1e3b4f1110a01e0", null ],
    [ "readText24", "namespaceKorg.html#a5ecd1e8f605dfa8cd3da6677a057c481", null ],
    [ "removeFileTypeExtension", "namespaceKorg.html#afba6872fb6e9d00ee2d2d513e3fa7253", null ]
];