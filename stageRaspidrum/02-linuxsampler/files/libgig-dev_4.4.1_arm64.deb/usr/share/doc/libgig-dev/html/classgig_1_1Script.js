var classgig_1_1Script =
[
    [ "Compression_t", "classgig_1_1Script.html#a0ccb50c6d26814e99757a0306163a6e6", [
      [ "COMPRESSION_NONE", "classgig_1_1Script.html#a0ccb50c6d26814e99757a0306163a6e6aaf5f72aed319b7b7c2b784c792c3e75a", null ]
    ] ],
    [ "Encoding_t", "classgig_1_1Script.html#a5dd291349d57530f86c89bf57dc6d7f8", [
      [ "ENCODING_ASCII", "classgig_1_1Script.html#a5dd291349d57530f86c89bf57dc6d7f8a3b5699fc4cdcd3206a9be0686bd2ecf6", null ]
    ] ],
    [ "Language_t", "classgig_1_1Script.html#a867300729de461694e4a858085a28538", [
      [ "LANGUAGE_NKSP", "classgig_1_1Script.html#a867300729de461694e4a858085a28538a59afba19c3ce4b56f58e203e41aa4b59", null ]
    ] ],
    [ "CopyAssign", "classgig_1_1Script.html#abe8c624ffa2ca891e5af6170e4780fd6", null ],
    [ "DeleteChunks", "classgig_1_1Script.html#ab1df001742f3f85d4c4b6de3e0a22e6b", null ],
    [ "GenerateUuid", "classgig_1_1Script.html#ada0ad80608e267bb0154e5569bf83bea", null ],
    [ "GetGroup", "classgig_1_1Script.html#ac21a52a5dd5f13393534548b6b85d20c", null ],
    [ "GetScriptAsText", "classgig_1_1Script.html#ab37781dafba0f2ed216a8454f10d4ff2", null ],
    [ "SetGroup", "classgig_1_1Script.html#a1ade88e94dd091bb01803f970c857359", null ],
    [ "SetScriptAsText", "classgig_1_1Script.html#ab23949fc4350b0dd97ebe0f0f06c9e7b", null ],
    [ "UpdateChunks", "classgig_1_1Script.html#a6a2955a7b62eccff3fc87e67be16bfb9", null ],
    [ "Bypass", "classgig_1_1Script.html#a87b75a51aa8a36e8847e2854f9dfbf09", null ],
    [ "Compression", "classgig_1_1Script.html#a0b500a581907264b6fa51795a6021533", null ],
    [ "Encoding", "classgig_1_1Script.html#a5097a166f0e7a33495029e88e0aa4100", null ],
    [ "Language", "classgig_1_1Script.html#a24ce1b99c6568bd2dbfdf3106b525353", null ],
    [ "Name", "classgig_1_1Script.html#aa4daa86c652615d870e54ab7abd75825", null ],
    [ "Uuid", "classgig_1_1Script.html#a5d0198bb0406740e42e1dfe87071f935", null ]
];