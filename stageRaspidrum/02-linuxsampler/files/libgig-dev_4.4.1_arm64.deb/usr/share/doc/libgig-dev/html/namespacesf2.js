var namespacesf2 =
[
    [ "Region", "classsf2_1_1Region.html", "classsf2_1_1Region" ],
    [ "libraryName", "namespacesf2.html#a9747681fdca66ee0f91863ba5870490b", null ],
    [ "libraryVersion", "namespacesf2.html#a483b7682d81ff0688d1415bca5c06c5a", null ],
    [ "VerifySize", "namespacesf2.html#a3038e5afc8542c03047f819c2d2e000a", null ]
];