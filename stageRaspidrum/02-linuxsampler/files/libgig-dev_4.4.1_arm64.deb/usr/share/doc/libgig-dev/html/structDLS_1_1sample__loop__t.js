var structDLS_1_1sample__loop__t =
[
    [ "LoopLength", "structDLS_1_1sample__loop__t.html#a1123894f1a2161f43a505e408895763f", null ],
    [ "LoopStart", "structDLS_1_1sample__loop__t.html#a8a1da90e789d3091f477958293245fc2", null ],
    [ "LoopType", "structDLS_1_1sample__loop__t.html#aa5594d4dcbcd91294701da2051c5e696", null ],
    [ "Size", "structDLS_1_1sample__loop__t.html#a4a4ae3a362c664ee70a07a7d9dd21f75", null ]
];