var classKorg_1_1KSFSample =
[
    [ "FrameSize", "classKorg_1_1KSFSample.html#a742ae1791d9111349d1e9a2e86efa588", null ],
    [ "GetCache", "classKorg_1_1KSFSample.html#a1b0b65133675d6b89f65fdf2a7a19622", null ],
    [ "GetPos", "classKorg_1_1KSFSample.html#ae0e12d17ebd741f641fde56d66c6d935", null ],
    [ "LoadSampleData", "classKorg_1_1KSFSample.html#a73152d6edebb59b2e5aa01c0db5f3cb2", null ],
    [ "LoadSampleData", "classKorg_1_1KSFSample.html#a729a999fcc700691a461c57e5c0d713e", null ],
    [ "LoadSampleDataWithNullSamplesExtension", "classKorg_1_1KSFSample.html#aab0ba3ad5e195b9d141540fe0429f71f", null ],
    [ "LoadSampleDataWithNullSamplesExtension", "classKorg_1_1KSFSample.html#a5365c42743243ec8bdb83a26694f7abe", null ],
    [ "Read", "classKorg_1_1KSFSample.html#a21338d659a4b12cb87cdacb40fde84d4", null ],
    [ "ReleaseSampleData", "classKorg_1_1KSFSample.html#abe5d1b2fffeea05fd0f7be4327b07f5c", null ],
    [ "SetPos", "classKorg_1_1KSFSample.html#a38a0e746707bfb349ddcdd25ee6c7d54", null ],
    [ "Attributes", "classKorg_1_1KSFSample.html#accdbad5987f6c99c3dd3526c0a87842b", null ],
    [ "BitDepth", "classKorg_1_1KSFSample.html#a08e448af1b01dee6ecfc56ef9acb7524", null ],
    [ "Channels", "classKorg_1_1KSFSample.html#a0f9b85d9ffea7cf0f0bc56fa40a3ccd9", null ],
    [ "DefaultBank", "classKorg_1_1KSFSample.html#a381dc1abc4a53f4346d168956c7085b3", null ],
    [ "LoopTune", "classKorg_1_1KSFSample.html#a2ee1b3642abddb9fa45ea3625749d7f0", null ],
    [ "Name", "classKorg_1_1KSFSample.html#a6d2c09067389f35b587744bd2f0935c9", null ],
    [ "SamplePoints", "classKorg_1_1KSFSample.html#a67125bad597f3e5647093eb6f99f3c64", null ],
    [ "SampleRate", "classKorg_1_1KSFSample.html#a936096d95bc562ecf0f724899fbeb9fa", null ]
];