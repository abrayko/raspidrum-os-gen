var classDLS_1_1Region =
[
    [ "~Region", "classDLS_1_1Region.html#a140042fe5b2de8770e11a668dd3fa8f0", null ],
    [ "AddSampleLoop", "classDLS_1_1Region.html#a717d9354651251aa9abec36801f09630", null ],
    [ "CopyAssign", "classDLS_1_1Region.html#aa0ff3b0f6e39dfb68a21fdb2a9b863c7", null ],
    [ "CopyAssign", "classDLS_1_1Region.html#a11c3a5d0050ffd3a24de84404fb45178", null ],
    [ "CopyAssign", "classDLS_1_1Region.html#acabeb02d06fe8c9286224bb30859ab75", null ],
    [ "CopyAssign", "classDLS_1_1Region.html#a22fd47782d302ca179c20d0de5545ab3", null ],
    [ "DeleteChunks", "classDLS_1_1Region.html#abeec79ce89dc993e6b89c31abd7cbf9c", null ],
    [ "DeleteSampleLoop", "classDLS_1_1Region.html#ad6cd0f66b87d6fe61b8dc8e8392a890b", null ],
    [ "GenerateDLSID", "classDLS_1_1Region.html#acabb2a1f6e02fe9110b4f4cb0319259a", null ],
    [ "GetArticulation", "classDLS_1_1Region.html#a9ca0c099812215455e48a6d68742db75", null ],
    [ "GetFirstArticulation", "classDLS_1_1Region.html#a417f163e45d32a9747dfffd9ba918149", null ],
    [ "GetNextArticulation", "classDLS_1_1Region.html#a210746a93cf2c9da3dd834e9c99b6eb4", null ],
    [ "SetKeyRange", "classDLS_1_1Region.html#ab2c9520fb40df2ad6e2918154d8c5cac", null ],
    [ "SetSample", "classDLS_1_1Region.html#a4cd62b9b0a9c88e83df7d49107302506", null ],
    [ "UpdateChunks", "classDLS_1_1Region.html#a53c6e0893cb7cf805ff4007da22d0f0c", null ],
    [ "Gain", "classDLS_1_1Region.html#aded64bedf4afdf6773e4ba872157c344", null ],
    [ "KeyRange", "classDLS_1_1Region.html#a770c0da40f8dcbb96e45a6f01d149bab", null ],
    [ "pDLSID", "classDLS_1_1Region.html#a52632417e3dc96481bdec2b76e18d359", null ],
    [ "pInfo", "classDLS_1_1Region.html#a34be00ec61a9888c5d0dc67f4c74f33d", null ],
    [ "pSampleLoops", "classDLS_1_1Region.html#acb1d8ac5aed3310787e0a960cd82ef04", null ],
    [ "SampleLoops", "classDLS_1_1Region.html#a7be8a9078496d44946af3230c2ccc80c", null ]
];