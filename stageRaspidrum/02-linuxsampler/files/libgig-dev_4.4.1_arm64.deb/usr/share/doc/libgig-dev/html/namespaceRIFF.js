var namespaceRIFF =
[
    [ "Chunk", "classRIFF_1_1Chunk.html", "classRIFF_1_1Chunk" ],
    [ "Exception", "classRIFF_1_1Exception.html", null ],
    [ "File", "classRIFF_1_1File.html", "classRIFF_1_1File" ],
    [ "List", "classRIFF_1_1List.html", "classRIFF_1_1List" ],
    [ "progress_t", "structRIFF_1_1progress__t.html", "structRIFF_1_1progress__t" ],
    [ "file_offset_t", "namespaceRIFF.html#aea52054397ea9a06fe740bee44582cb6", null ],
    [ "endian_t", "namespaceRIFF.html#aadd0060ac1ca79895965c21824932af0", [
      [ "endian_little", "namespaceRIFF.html#aadd0060ac1ca79895965c21824932af0aba3f8989f99216ba211a4d3f1449e51b", null ],
      [ "endian_big", "namespaceRIFF.html#aadd0060ac1ca79895965c21824932af0ad70d4c403f95ee17d1e5804f8c3c8526", null ],
      [ "endian_native", "namespaceRIFF.html#aadd0060ac1ca79895965c21824932af0ad1b39b34c9e4a9761127085a46f4049e", null ]
    ] ],
    [ "layout_t", "namespaceRIFF.html#a9f8da9cdd60dae232df405ecbb866bcd", [
      [ "layout_standard", "namespaceRIFF.html#a9f8da9cdd60dae232df405ecbb866bcda7bd532916f4f53b57dba91236544597c", null ],
      [ "layout_flat", "namespaceRIFF.html#a9f8da9cdd60dae232df405ecbb866bcdac6b865ce1f0f63b8e09e791a59dee63c", null ]
    ] ],
    [ "offset_size_t", "namespaceRIFF.html#a91dc6aeea948a074b39956fb81b9cf0a", [
      [ "offset_size_auto", "namespaceRIFF.html#a91dc6aeea948a074b39956fb81b9cf0aa9b1aaf52e32b0fe2e23b050862d510dc", null ],
      [ "offset_size_32bit", "namespaceRIFF.html#a91dc6aeea948a074b39956fb81b9cf0aadcb8f908ece53071c97994d12876899a", null ],
      [ "offset_size_64bit", "namespaceRIFF.html#a91dc6aeea948a074b39956fb81b9cf0aa6b2f6dfb2387760d6f87e9fd7c690509", null ]
    ] ],
    [ "stream_mode_t", "namespaceRIFF.html#a93e8fe9881fc3e1ab4fa5ead0598b525", [
      [ "stream_mode_read", "namespaceRIFF.html#a93e8fe9881fc3e1ab4fa5ead0598b525ae94b633e6260eb9de0216b6840be225f", null ],
      [ "stream_mode_read_write", "namespaceRIFF.html#a93e8fe9881fc3e1ab4fa5ead0598b525ae7d0001043aaaa5ec18a3735883fc23f", null ],
      [ "stream_mode_closed", "namespaceRIFF.html#a93e8fe9881fc3e1ab4fa5ead0598b525afbccd62e0347eea9566e86378989ee0e", null ]
    ] ],
    [ "stream_state_t", "namespaceRIFF.html#a1c9a97c3deb7b0a6e671c0b947ef4445", [
      [ "stream_ready", "namespaceRIFF.html#a1c9a97c3deb7b0a6e671c0b947ef4445af73c3b3a81e05d90f804ceefbdbcae5c", null ],
      [ "stream_end_reached", "namespaceRIFF.html#a1c9a97c3deb7b0a6e671c0b947ef4445a8e6941b2b80cf8944933ca304e0d8354", null ],
      [ "stream_closed", "namespaceRIFF.html#a1c9a97c3deb7b0a6e671c0b947ef4445a26b702a10a8f3ba3327fb228a0f74711", null ]
    ] ],
    [ "stream_whence_t", "namespaceRIFF.html#a0d7db9bee8a06fb344d95bcbc4997337", [
      [ "stream_start", "namespaceRIFF.html#a0d7db9bee8a06fb344d95bcbc4997337a52592d3e26eee4a575743c2851e3e5a3", null ],
      [ "stream_curpos", "namespaceRIFF.html#a0d7db9bee8a06fb344d95bcbc4997337abb52409f40ca6b8e09c9a7784e96e934", null ],
      [ "stream_backward", "namespaceRIFF.html#a0d7db9bee8a06fb344d95bcbc4997337a2d45e5892498e22b3c3dcca8cb6dc3cd", null ],
      [ "stream_end", "namespaceRIFF.html#a0d7db9bee8a06fb344d95bcbc4997337aed156e80d0f72639f5b7fa748150339d", null ]
    ] ],
    [ "libraryName", "namespaceRIFF.html#a3870214a668519283621918df9f43a35", null ],
    [ "libraryVersion", "namespaceRIFF.html#a043609b013beac4b9dac91950abd2a45", null ]
];